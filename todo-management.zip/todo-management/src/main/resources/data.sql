INSERT INTO users(user_name,password,user_role) values('user1','user1','USER');
INSERT INTO users(user_name,password,user_role) values('admin','admin','USER');